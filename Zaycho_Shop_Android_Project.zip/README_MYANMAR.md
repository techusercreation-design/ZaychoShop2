# Zaycho Shop Android App Project

ဤ ZIP ဖိုင်တွင် `https://zaycho.shop/shop` အတွက် အောက်ပါစနစ်များ အပြည့်အစုံပါဝင်သော Android Studio Project ပါဝင်ပါသည် -
1. **Pull-to-Refresh:** လက်ဖြင့် အပေါ်မှအောက်သို့ ဆွဲချ၍ စာမျက်နှာ Refresh လုပ်နိုင်ခြင်း။
2. **Custom Offline Page:** အင်တာနက်လိုင်း ပြတ်တောက်နေချိန်တွင် မြန်မာဘာသာဖြင့် Offline မျက်နှာပြင်နှင့် "ပြန်လည်ကြိုးစားမည်" ခလုတ် ပြသပေးခြင်း။
3. **File Upload / Chooser:** ဈေးဝယ်သူများမှ ငွေလွှဲပြေစာ (Screenshot) သို့မဟုတ် ဓာတ်ပုံများ ရွေးချယ်တင်နိုင်ခြင်း။
4. **External Links:** ဖုန်းခေါ်ဆိုမှု၊ Viber နှင့် Messenger လင့်ခ်များကို သက်ဆိုင်ရာ App များဖြင့် တိုက်ရိုက်ဖွင့်ပေးခြင်း။

## APK ဖိုင်ထုတ်ယူရန် နည်းလမ်း (၂) ခု

### နည်းလမ်း (၁) - Android Studio ဖြင့် ထုတ်ယူခြင်း
1. ဤ ZIP ဖိုင်ကို ဖြည်ပါ (Extract လုပ်ပါ)။
2. Android Studio ကိုဖွင့်ပြီး **Open** ကိုနှိပ်၍ ဖြည်ထားသော ဖိုဒါကို ရွေးပါ။
3. Gradle Sync ပြီးသွားပါက **Build > Build Bundle(s) / APK(s) > Build APK(s)** ကိုနှိပ်၍ APK ထုတ်ယူနိုင်ပါသည်။

### နည်းလမ်း (၂) - Android Studio မသုံးဘဲ GitHub ဖြင့် အလိုအလျောက် APK ထုတ်ယူခြင်း
Project ထဲတွင် `.github/workflows/build_apk.yml` ထည့်သွင်းပေးထားသောကြောင့် ကွန်ပျူတာတွင် Android Studio မရှိပါကလည်း GitHub ပေါ်တင်၍ APK တိုက်ရိုက်ထုတ်ယူနိုင်ပါသည် -
1. GitHub တွင် Repository အသစ်တစ်ခု ဖွင့်ပြီး ဖြည်ထားသော ဖိုင်များအားလုံးကို Upload တင်ပါ။
2. Repository ၏ **Actions** tab သို့ သွားပါ။
3. **Build Zaycho Shop APK** အလုပ်လုပ်ပြီးစီးသွားပါက အောက်ဆုံးရှိ **Artifacts (Zaycho-Shop-APK)** တွင် အသင့်သုံး `.apk` ဖိုင်ကို ဒေါင်းလုဒ်ဆွဲယူနိုင်ပါသည်။
